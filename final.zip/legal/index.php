<?php
 header("Location: ../");
 exit();
?>